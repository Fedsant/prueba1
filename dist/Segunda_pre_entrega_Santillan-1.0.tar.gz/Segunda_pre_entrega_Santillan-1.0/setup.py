from setuptools import setup

setup(
    name ="Segunda_pre_entrega_Santillan",
    version="1.0",
    description="Segunda entrega",
    author="federico santillan",
    author_email="fede.santillan@gmail.com",
    packages=["Cliente_Tienda"]
)